var mongoose = require('mongoose');

var Schema = mongoose.Schema;

var MovieSchema = new Schema(
  {
    title: {type: String, required: true},
    director: {type: String, required: true},
    year: {type: Number, required: true}
  }
);

//Export model
module.exports = mongoose.model('Movie', MovieSchema);