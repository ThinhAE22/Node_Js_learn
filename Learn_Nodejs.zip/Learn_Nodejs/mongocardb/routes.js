const express = require('express');
const router = express.Router();
const Car = require('./models/car');

// Fetch all cars
router.get("/cars", async (req, res) => {
  try {
    const cars = await Car.find();
    res.send(cars);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Add car
router.post("/cars", async (req, res) => {
  const { brand, model, color, year } = req.body;
  
  if (!brand || !model || !color || !year) {
    return res.status(400).json({ message: "Brand, model, color and year are required" });
  }

  const car = new Car({
    brand,
    model,
    color,
    year
  });

  try {
    const newCar = await car.save();
    res.status(201).json(newCar);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Delete car by title
router.delete("/cars", async (req, res) => {
  const { brand } = req.body;

  if (!brand) {
    return res.status(400).json({ message: "Brand is required" });
  }

  try {
    const result = await Car.deleteOne({ title });
    if (result.deletedCount === 0) {
      return res.status(404).json({ message: "Car not found" });
    }
    res.status(200).json({ message: "Car deleted" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Update car by id
router.put("/cars/:id", async (req, res) => {
  const { id } = req.params;
  const updates = req.body;

  try {
    const updatedCar = await Car.findOneAndUpdate({ _id: id }, updates, { new: true });

    if (!updatedCar) {
      return res.status(404).json({ message: "Car not found" });
    }

    res.status(200).json(updatedCar);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});
module.exports = router;
