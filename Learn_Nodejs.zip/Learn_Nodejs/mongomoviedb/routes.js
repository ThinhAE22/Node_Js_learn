const express = require('express');
const router = express.Router();
const Movie = require('./models/movie');

// Fetch all movies
router.get("/movies", async (req, res) => {
  try {
    const movies = await Movie.find();
    res.send(movies);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Add movie
router.post("/movies", async (req, res) => {
  const { title, director, year } = req.body;
  
  if (!title || !director || !year) {
    return res.status(400).json({ message: "Title, director, and year are required" });
  }

  const movie = new Movie({
    title,
    director,
    year
  });

  try {
    const newMovie = await movie.save();
    res.status(201).json(newMovie);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Delete movie by title
router.delete("/movies", async (req, res) => {
  const { title } = req.body;

  if (!title) {
    return res.status(400).json({ message: "Title is required" });
  }

  try {
    const result = await Movie.deleteOne({ title });
    if (result.deletedCount === 0) {
      return res.status(404).json({ message: "Movie not found" });
    }
    res.status(200).json({ message: "Movie deleted" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Update movie by id
router.put("/movies/:id", async (req, res) => {
  const { id } = req.params;
  const updates = req.body;

  try {
    const updatedMovie = await Movie.findOneAndUpdate({ _id: id }, updates, { new: true });

    if (!updatedMovie) {
      return res.status(404).json({ message: "Movie not found" });
    }

    res.status(200).json(updatedMovie);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});
module.exports = router;
